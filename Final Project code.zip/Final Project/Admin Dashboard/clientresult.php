<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project _data";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name, phone, email, location FROM cli_registration";
$result = $conn->query($sql);

echo "<!DOCTYPE html>
<html>
<head>
    <title>Clients</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 18px;
            text-align: left;
        }
        table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
            font-weight: bold;
        }
        table th, table td {
            padding: 12px 15px;
            border: 1px solid #dddddd;
        }
        table tbody tr {
            border-bottom: 1px solid #dddddd;
        }
        table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }
        table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
    </style>
</head>
<body>";

if ($result->num_rows > 0) {
    echo "<table><thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>Location</th></tr></thead><tbody>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["name"]. "</td><td>" . $row["phone"]. "</td><td>" . $row["email"]. "</td><td>" . $row["location"]. "</td></tr>";
    }
    echo "</tbody></table>";
} else {
    echo "0 results";
}

echo "</body></html>";

$conn->close();
?>
