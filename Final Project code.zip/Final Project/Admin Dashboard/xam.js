const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const ejs = require('ejs');
const app = express();
const port = 3070;

// Set up in-memory counters
let doctorLogins = 0;
let clientLogins = 0;
let appointmentsBooked = 0;
let homePageVisits = 0;

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'admin'
});
  

const connect = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'project _data'
});
// Connect to MySQL
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL as id ' + connection.threadId);
});

// Connect to MySQL
connect.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL as id ' + connection.threadId);
});
// Set EJS as the view engine
app.set('view engine', 'ejs');

// Serve static files from the public folder
app.use(express.static('public'));

app.use(bodyParser.urlencoded({ extended: false }));

// Parse application/json
app.use(bodyParser.json());

const userData = [];

// Route to handle form submission
app.post('/submit', (req, res) => {
    const { name, email } = req.body;
    userData.push({ name, email });
    res.redirect('/');
});

// Define a single route to handle rendering the admin dashboard and fetching data from the database
/*app.get('/nw', (req, res) => {
    // First, increment homePageVisits count
    homePageVisits++;

    // Query the database
    connection.query('SELECT * FROM admin_entry', (error, results) => {
        if (error) {
            console.error('Error fetching data from database: ' + error.stack);
            res.status(500).send('Error fetching data from database');
            return;
        }
        
        // Render admin dashboard with fetched data
        res.render('nw', {
            doctorLogins,
            clientLogins,
            appointmentsBooked,
            homePageVisits,
            userData: results  // Pass fetched data to the view
        });
    });
});*/


app.get('/nw', (req, res) => {
    homePageVisits++;
    
    // Query the database to get the count of appointments booked
    connect.query('SELECT COUNT(*) AS count FROM cli_registration', (error, results) => {
        if (error) {
            console.error('Error fetching appointment count from database: ' + error.stack);
            res.status(500).send('Error fetching appointment count from database');
            return;
        }
        
        // Extract the appointment count from the results
        const appointmentsBooked = results[0].count;
          
        // Query the database to get the count of appointments booked
    connect.query('SELECT COUNT(*) AS count FROM doc_registration', (error, results) => {
        if (error) {
            console.error('Error fetching appointment count from database: ' + error.stack);
            res.status(500).send('Error fetching appointment count from database');
            return;
        }
        
        // Extract the appointment count from the results
        const doctorLogins = results[0].count;

        // Query the database to get the count of appointments booked
    connect.query('SELECT COUNT(*) AS count FROM cli_registration', (error, results) => {
        if (error) {
            console.error('Error fetching appointment count from database: ' + error.stack);
            res.status(500).send('Error fetching appointment count from database');
            return;
        }
        
        // Extract the appointment count from the results
        const clientLogins = results[0].count;

        // Query the database for other necessary data
        connect.query(`SELECT cli_registration.id AS Client_id, doc_registration.name AS Doctor_Name, doc_registration.phone AS Doctor_Phone, cli_registration.name AS Client_Name, cli_registration.phone AS Client_Phone
        FROM  cli_registration
        INNER JOIN doc_registration ON cli_registration.doctor_id = doc_registration.id` , (error, results) => {
            if (error) {
                console.error('Error fetching data from database: ' + error.stack);
                res.status(500).send('Error fetching data from database');
                return;
            }
            
            // Render admin dashboard with fetched data
            res.render('nw', {
                doctorLogins,
                clientLogins,
                appointmentsBooked, // Pass the fetched appointment count to the view
                homePageVisits,
                userData: results  // Pass fetched data to the view
            });
        });
    });

});
});
});

// Default route for the root URL
app.get('/', (req, res) => {
    homePageVisits++;
    res.send('Welcome to the homepage!');
});
 
//fetching
app.get('/fetchData', (req, res) => {
    const type = req.query.type;

    
    if (type === 'doctors') {
        connect.query = 'SELECT * FROM doc_registration';
    } else if (type === 'clients') {
        connect.query = 'SELECT * FROM cli_registration';
    } else if (type === 'pets') {
        connect.query = 'SELECT * FROM cli_registration';
    } else {
        return res.status(400).json({ error: 'Invalid type' });
    }

    connection.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);

        
    });
});

// Simulate doctor login
app.get('/doctor-login', (req, res) => {
    doctorLogins++;
    res.send('Doctor login successful');
});

// Simulate client login
app.get('/client-login', (req, res) => {
    clientLogins++;
    res.send('Client login successful');
});

// Simulate appointment booking
app.get('/book-appointment', (req, res) => {
    appointmentsBooked++;
    res.send('Appointment booked successfully');
});

app.get('/form', (req, res) => {
    res.render('home'); // Assuming 'home' is the name of your EJS file for the form
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
