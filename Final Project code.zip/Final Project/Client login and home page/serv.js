const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

//const { name } = require('ejs');
//const axios = require('axios'); // Import axios package

const app = express();
const port = 1370;



// Set EJS as the view engine
app.set('view engine', 'ejs');

// Set the directory for views (assuming 'views' directory contains your EJS files)
app.set('views', './views');


// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'appointments'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database');
});

// Dummy database for user profile data
let userProfile = {
    name: '',
    phone: '',
    email: '',
    location: '',
    petName: '',
    petCount: 0
};

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));




// Login route
app.post('/login1', (req, res) => {
    // Dummy authentication (replace with actual authentication logic)
    const { username, password } = req.body;
    if (username === 'user' && password === 'pass') {
        res.redirect('/home');
    } else {
        res.send('Invalid credentials');
    }
});

// Home route



// Route to handle form submission

// Home route
app.get('/new3', (req, res) => {
    res.render('new3', { userProfile });
});

// Update profile route
app.post('/update-profile', (req, res) => {
    // Update user profile data
    userProfile = { ...userProfile, ...req.body };
    res.redirect('/new3');
});







// Home route


app.get('/fetchData', (req, res) => {
    const phone = req.query.phone;


    const sql = `SELECT * FROM appoint WHERE User_phone = '${phone}'`;

    db.query(sql, (err, result) => {
        if (err) throw err;

        if (result.length > 0) {
            res.render('userdibu', { userData: result });
        } else {
            res.send('No Appointment booked with this phone number');
        }
    });
});

app.listen(port, () => {
    console.log(`Server is listening at http://localhost:${port}`);
});

