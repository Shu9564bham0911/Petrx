const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const port = 8312;

// Create MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'project _data'
});

// Set the view engine to EJS
// app.set('view engine', 'ejs');

app.use(express.static('public'));

// Connect to MySQL
db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Signup form route
app.post('/newdocsignup', (req, res) => {
    const { name, email, password ,phone ,location ,specialization,photo,fees} = req.body;
  
    // Check if any of the required fields are empty
    if (!name || !email || !password || !phone || !location || !specialization ||  !photo || !fees) {
      return res.status(400).send('Name, email, and password are required');
    }
  
    const user = { name, email, password ,phone ,location ,specialization,photo,fees};
    db.query('INSERT INTO doc_registration SET ?', user, (err, result) => {
      if (err) {
        console.error('Error signing up user:', err);
        return res.status(500).send('Error signing up user');
      }
      console.log('User signed up successfully');
      res.redirect('/newdoclogin');
    });
});

  

// Login form route
app.post('/newdoclogin', (req, res) => {
  const { email, password } = req.body;
  db.query('SELECT * FROM doc_registration WHERE email = ? AND password = ?', [email, password], (err, results) => {
    if (err) throw err;
    if (results.length > 0) {
      console.log('Login successful');
      res.redirect('/home');
    } else {
      res.send('Incorrect email or password');
    }
  });
});

// Home page route
app.get('/home', (req, res) => {
    res.redirect('http://localhost:1485/new_doc');
  });

// Serve signup and login forms
/*app.get('/newsignup', (req, res) => {
  res.sendFile(__dirname + '/html/register.html');
  // res.render('registration'); // If using EJS
});

app.get('/newlogin', (req, res) => {
  res.sendFile(__dirname + '/html/HTML1.html');
});*/

// Serve signup and login forms
app.get('/newdocsignup', (req, res) => {
    res.sendFile('ht.html', { root: 'public' });
  });
  
  app.get('/newdoclogin', (req, res) => {
    res.sendFile('html2.html', { root: 'public' });
  });

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
