const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

//const { name } = require('ejs');
//const axios = require('axios'); // Import axios package

const app = express();
const port = 1485;



// Set EJS as the view engine
app.set('view engine', 'ejs');

// Set the directory for views (assuming 'views' directory contains your EJS files)
app.set('views', './views');


// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'project _data'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database');
});

// Dummy database for user profile data
let userProfile = {
    name: '',
    phone: '',
    email: '',
    location: '',
    specialization: '',
    fees: 0
};

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));




// Login route
app.post('/login1', (req, res) => {
    // Dummy authentication (replace with actual authentication logic)
    const { username, password } = req.body;
    if (username === 'user' && password === 'pass') {
        res.redirect('/home');
    } else {
        res.send('Invalid credentials');
    }
});

// Home route



// Route to handle form submission

// Home route
app.get('/new_doc', (req, res) => {
    res.render('new_doc', { userProfile });
});


  

// Update profile route
app.post('/update-profile', (req, res) => {
    // Update user profile data
    userProfile = { ...userProfile, ...req.body };
    res.redirect('/new_doc');
});







// Home route
/*

app.get('/fetchData', (req, res) => {
    const phone = req.query.phone;


    const sql = `SELECT * FROM appoint WHERE User_phone = '${phone}'`;

    db.query(sql, (err, result) => {
        if (err) throw err;

        if (result.length > 0) {
            res.render('userdibu', { userData: result });
        } else {
            res.send('No Appointment booked with this phone number');
        }
    });
});*/

// Route to fetch data
app.get('/fetchData', (req, res) => {
    const phone = req.query.phone;

    // Execute the query with WHERE clause
    db.query(`SELECT cli_registration.id, doc_registration.name AS Doctor_Name, doc_registration.phone AS Doctor_phone, cli_registration.name, cli_registration.phone \
                FROM  cli_registration
                INNER JOIN doc_registration ON cli_registration.doctor_id = doc_registration.id \
                WHERE doc_registration.phone = ?`, [phone], (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        
        if (results.length > 0) {
            res.render('doc_info', { userData: results });
        } else {
            res.send('No Appointment booked with this phone number');
        }
    });
});

// Define a route to render the EJS template for today's appointments
app.get('/today-appointments', (req, res) => {
    // Get today's date
    const todayDate = new Date().toISOString().slice(0, 10);
  
    // Query to fetch today's appointments from the cli_registration table
    const sql = `SELECT * FROM cli_registration WHERE \`date\` = '${todayDate}'`;
    db.query(sql, (err, results) => {
      if (err) {
        console.error('Error fetching appointments:', err);
        res.status(500).send('Error fetching appointments');
        return;
      }
  
      // Render the EJS template with the fetched appointments
      res.render('today-appointments.ejs', { appointments: results });
    });
  });
  



app.listen(port, () => {
    console.log(`Server is listening at http://localhost:${port}`);
});