<?php
// Establish a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project _data"; // Removed the space in the database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form has been submitted via POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['searchTerm'], $_POST['searchOption'])) { // Check if search parameters are set
        $searchTerm = $_POST['searchTerm'];
        $searchOption = $_POST['searchOption'];

        // Define your SQL query based on the selected option
        if ($searchOption === 'specialization') {
            $sql = "SELECT * FROM doc_registration WHERE specialization LIKE '%$searchTerm%'";
        } elseif ($searchOption === 'location') {
            $sql = "SELECT * FROM doc_registration WHERE location LIKE '%$searchTerm%'";
        } elseif ($searchOption === 'name') {
            $sql = "SELECT * FROM doc_registration WHERE name LIKE '%$searchTerm%'";
        }

        // Execute the SQL query
        $result = $conn->query($sql);

        // Define the variable outside of the loop to avoid "Undefined variable" warning
        //$photoSrc = "";

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='box'>";
                //pic
                $photoSrc = $row['photo'];
               // echo "Photo Source: " . $photoSrc . "<br>";
                if ($photoSrc && file_exists($photoSrc) || filter_var($photoSrc, FILTER_VALIDATE_URL)) {
                    echo '<img src="' . $photoSrc . '" alt="Doctor Picture" width="100"><br>';
                } else {
                    echo '<p>No photo available</p>';
                }

                echo "<h2>" . $row["name"] . "</h2>";
                echo "<p>Specialization:  " . $row["specialization"] . "</p>";
                echo "<p>Clinic_location: " . $row["location"] . "</p>";
                echo "<p>Phone No: " . $row["phone"] . "</p>";
                echo "<p>Email: " . $row["email"] . "</p>";
                echo "<p>Fees: " . $row["fees"] . "</p>";
                echo "<button class='book-button' onclick='bookDoctor(" . $row["id"] . ")'>Book</button>";
                echo "</div>";
            }
        } else {
            echo "0 results";
        }
    } elseif (isset($_POST['doctor_id'], $_POST['name'], $_POST['phone'], $_POST['email'], $_POST['location'])) {
        // Insert the booked appointment data into cli_registration table
        $doctorId = $_POST['doctor_id'];
        $name = $_POST['name'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $petname = $_POST['Pet_name'];
        $pettype = $_POST['Pet_type'];
        $Breed = $_POST['Breed'];
        $location = $_POST['location'];
        $date = $_POST['date'];
        $time = $_POST['time'];

        $sql = "INSERT INTO cli_registration (doctor_id, name, phone, email,Pet_name,Pet_type,Breed, location,date,time) 
                VALUES ('$doctorId', '$name', '$phone', '$email', '$petname','$pettype','$Breed','$location','$date','$time')";

        if ($conn->query($sql) === TRUE) {
            echo "<p class='success-message'>Appointment booked successfully!</p>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Error: Please fill all the fields."; // Error message if search parameters are not set
    }
}

// Fetch all doctors from the database
$sql = "SELECT * FROM doc_registration";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- HTML Head Section -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Doctors</title>
    <style>
        /* CSS styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('newdoc2.jpg'); /* Replace 'background-image.jpg' with your image file path */
            background-size: cover;
            background-position: center top;
            background-repeat: no-repeat;
        }
        header {
            text-align: center;
            padding: 20px 0;
        }
        main {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        button {
            padding: 10px 20px;
            margin-bottom: 10px;
            cursor: pointer;
            border: none;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
        }
        #searchOptions, #searchBar {
            display: none;
        }
        #searchInput {
            padding: 8px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        #searchButton {
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .box {
            width:auto;
            min-width: 200px;
            max-width: 400px;
            height: auto; /* Increased height to fit more info */
            border: 1px solid #ccc;
            margin: 10px;
            padding: 10px;
            text-align: center;
            transition: transform 0.3s ease;
            background-color:#5ec6a2ba;
            border-radius:10px;
            display: inline-block; /* Display boxes side by side */
    vertical-align: top; /* Align boxes to the top */
    box-sizing: border-box; /* Include padding and border in box size */
    white-space: nowrap; /* Prevent line breaks between boxes */
        }
        .box:hover {
            transform: scale(1.05);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .book-button {
            background-color: #4CAF50;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .book-button:hover {
            background-color: #45a049;
        }
        .success-message {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }
        #book-form {
            display: none;
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin: 0 auto;
            margin-top: 20px;
        }
        #book-form h2 {
            margin-bottom: 20px;
            text-align: center;
        }
        #book-form label {
            display: block;
            margin-bottom: 10px;
        }
        #book-form input[type="text"],
        #book-form input[type="email"],
        #book-form input[type="date"],
        #book-form input[type="time"] {
            width: calc(100% - 12px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        #book-form button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        #book-form button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <!-- HTML Body Section -->
    <header>
        <?php if ($_SERVER["REQUEST_METHOD"] != "POST"): ?>
            <h1>Find Specialist Doctors</h1>
        <?php endif; ?>
    </header>
    <main>
        <?php if ($_SERVER["REQUEST_METHOD"] != "POST"): ?>
            <button id="findButton">Find</button>
        <?php endif; ?>
        <div id="searchOptions">
            <label>
                <input type="radio" name="searchOption" value="specialization"> Specialization
            </label>
            <label>
                <input type="radio" name="searchOption" value="location"> Location
            </label>
            <label>
                <input type="radio" name="searchOption" value="name"> Name
            </label>
        </div>
        <div id="searchBar">
            <input type="text" id="searchInput" placeholder="Enter your search...">
            <button id="searchButton">Search</button>
        </div>
        <div id="searchResults"></div>
    </main>
    <div id="book-form">
        <h2>Book Appointment</h2>
        <form id="appointment-form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="hidden" id="doctor-id" name="doctor_id" value="">
            <label for="name">Your Name:</label>
            <input type="text" id="name" name="name" required><br>
            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" required><br>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>
            <label for="Pet_name">Pet Name:</label>
            <input type="text" id="Pet_name" name="Pet_name" required><br>
            <label for="Pet_type">Pet Type:</label>
            <input type="text" id="Pet_type" name="Pet_type" required><br>
            <label for="Breed">Breed:</label>
            <input type="text" id="Breed" name="Breed" required><br>
            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required><br>
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required><br>
        
            <label for="time">Time:</label>
            <input type="time" id="time" name="time" required><br>
            <button id="submitBtn" type="submit">Submit</button>
        </form>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const findButton = document.getElementById('findButton');
            const searchOptionsDiv = document.getElementById('searchOptions');
            const searchOptions = document.getElementsByName('searchOption');
            const searchBar = document.getElementById('searchBar');
            const searchButton = document.getElementById('searchButton');
            const searchInput = document.getElementById('searchInput');
            const bookForm = document.getElementById('book-form');
            const submitBtn = document.getElementById('submitBtn');

            for (let i = 0; i < searchOptions.length; i++) {
                searchOptions[i].addEventListener('click', () => {
                    searchBar.style.display = 'block';
                    for (let j = 0; j < searchOptions.length; j++) {
                        searchOptions[j].checked = false;
                    }
                    searchOptions[i].checked = true;
                });
            }

            findButton.addEventListener('click', () => {
                searchOptionsDiv.style.display = 'block';
            });

            searchButton.addEventListener('click', () => {
                const searchTerm = searchInput.value.trim();
                const selectedOption = document.querySelector('input[name="searchOption"]:checked');

                if (!selectedOption) {
                    alert('Please select a search option.');
                    return;
                }

                if (searchTerm === '') {
                    alert('Please enter a search term.');
                    return;
                }

                const selectedValue = selectedOption.value;

                // Send an AJAX request to the server
                const xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo $_SERVER["PHP_SELF"]; ?>', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        document.getElementById('searchResults').innerHTML = xhr.responseText;
                    }
                };
                xhr.send(`searchTerm=${encodeURIComponent(searchTerm)}&searchOption=${encodeURIComponent(selectedValue)}`);
            });

            submitBtn.addEventListener('click', (e) => {
                e.preventDefault();
                const formData = new FormData(bookForm);
                const xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo $_SERVER["PHP_SELF"]; ?>', true);
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        alert(xhr.responseText);
                    }
                };
                xhr.send(formData);
            });
        });

        //doctor book 
        function bookDoctor(doctorId) {
            document.getElementById("doctor-id").value = doctorId;
            document.getElementById("book-form").style.display = "block";
        }
    </script>
</body>
</html>
